'use strict';

// Selecting elements
const score0El = document.querySelector(`#score--0`);
const score1El = document.getElementById(`score--1`);
const current0El = document.getElementById(`current--0`);
const current1El = document.getElementById(`current--1`);
const diceEl = document.querySelector(`.dice`);
const btnNew = document.querySelector(`.btn--new`);
const btnRoll = document.querySelector(`.btn--roll`);
const btnHold = document.querySelector(`.btn--hold`);
const player1 = document.querySelector(`.player--0`);
const player2 = document.querySelector(`.player--1`);

//Starting conditions
score0El.textContent = 0;
score1El.textContent = 0;
diceEl.classList.add(`hidden`);

let scores, currentScore, activePlayer, playing;

//initiate game function
const init = function () {
  diceEl.classList.add(`hidden`);
  scores = [0, 0];
  currentScore = 0;
  activePlayer = 0;
  playing = true;

  score0El.textContent = 0;
  score1El.textContent = 0;
  current0El.textContent = 0;
  current1El.textContent = 0;

  document.querySelector(`.player--0`).classList.remove(`player--winner`);
  document.querySelector(`.player--1`).classList.remove(`player--winner`);
  document.querySelector(`.player--1`).classList.remove(`player--active`);
  document.querySelector(`.player--0`).classList.add(`player--active`);
};
init();

//Switch Players
const switchPlayer = function () {
  currentScore = 0;
  document.getElementById(`current--${activePlayer}`).textContent = 0;
  activePlayer = activePlayer === 0 ? 1 : 0;
  player1.classList.toggle(`player--active`);
  player2.classList.toggle(`player--active`);
};

//Rolling Dice Functionality
btnRoll.addEventListener(`click`, function () {
  if (playing) {
    //generate a random dice roll
    const diceRoll = Math.trunc(Math.random() * 6) + 1;

    //Display Dice
    diceEl.classList.remove(`hidden`);
    diceEl.src = `dice-${diceRoll}.png`;
    //add score
    if (diceRoll !== 1) {
      currentScore = currentScore + diceRoll;
      // current0El.textContent = currentScore; // change later
      document.getElementById(
        `current--${activePlayer}`
      ).textContent = currentScore;
    } else {
      switchPlayer();
    }
  }
});
//Hold score
btnHold.addEventListener(`click`, function () {
  if (playing) {
    scores[activePlayer] = scores[activePlayer] + currentScore;
    document.getElementById(`score--${activePlayer}`).textContent =
      scores[activePlayer];

    if (scores[activePlayer] >= 75) {
      diceEl.classList.add(`hidden`);
      playing = false;

      document
        .querySelector(`.player--${activePlayer}`)
        .classList.add(`player--winner`);

      document
        .querySelector(`.player--${activePlayer}`)
        .classList.remove(`player--active`);
    } else {
      switchPlayer();
    }
  }
});

btnNew.addEventListener(`click`, function () {
  init();
});
